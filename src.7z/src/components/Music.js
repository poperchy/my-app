import React from 'react';
import s from '../css/Dialogs.module.css'

const Music = (props) => {
    return(
        <div>
            Music
        </div>
    );
};

export default Music;