import React from 'react';
import s from '../css/Dialogs.module.css'

const News = (props) => {
    return(
        <div>
            News
        </div>
    );
};

export default News;