import React from 'react';
import s from '../css/Dialogs.module.css'

const Settings = (props) => {
    return(
        <div>
            Settings
        </div>
    );
};

export default Settings;