import React from 'react';

let Users = (props) => {
    return (
        <div>

        </div>
    )
};

export default Users;