//
//
// const friendsReducer = (state, action) => {
//
//     if (action.type === ADD_POST) {
//
//
//     return state;
// };
//
// export default friendsReducer();