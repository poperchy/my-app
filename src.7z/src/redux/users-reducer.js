const FOLLOW = 'FOLLOW';
const UNFOLLOW = 'UNFOLLOW';

let initialState = {
    users: [
        {id: 1, followed: false, fullName: 'Dmitry', status: 'im fine', location: {city: 'Minsk', country: 'Belarus'}},
        {id: 2, followed: true, fullName: 'Andrey', status: 'kek', location: {city: 'Moscow', country: 'Russia'}},
        {id: 3, followed: false, fullName: 'Eliza', status: 'lol', location: {city: 'NY', country: 'USA'}},
    ]
};
const usersReducer = (state = initialState, action) => {
    switch (action.type) {
        default :
            return state;
    }
};

export const followAC = () => ({type: FOLLOW});
export const unfollowAC = () => ({type: UNFOLLOW});

export default usersReducer;